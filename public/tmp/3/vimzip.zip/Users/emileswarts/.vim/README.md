
 The .vimrc file has folds to categorize hacks.  Best viewed in vim.

 Installation:

    git clone git@github.com:emileswarts/vim.git

Create symlinks:

    ln -s ~/.vim/.vimrc ~/.vimrc
